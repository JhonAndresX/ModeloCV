/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ModeloPersona;
import Modelo.Persona;
import Vista.MenuPrincipal;
import Vista.VistaPersonas;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ASUS
 */
public class ControladorPersona {

    private ModeloPersona modelo;
    private VistaPersonas vista;
    String Ruta = "";

    public ControladorPersona(ModeloPersona modelo, VistaPersonas vista) {
        this.modelo = modelo;
        this.vista = vista;
        vista.setVisible(true);
        cargaPersonas();

    }

    public void iniciaControl() {
        vista.getBtnConsultar().addActionListener(o -> buscar());
        vista.getBtnCrear().addActionListener(l -> abrirDialogo("Crear"));
        vista.getBtnEditar().addActionListener(l -> abrirDialogo("Editar"));
        vista.getBtnRemover().addActionListener(l -> abrirDialogo("Eliminar"));
        vista.getBtnLimpiar().addActionListener(l -> limpiarbusqueda());
        vista.getBtnSalir1().addActionListener(l -> salirdialogo());
        vista.getBtnAceptar().addActionListener(l -> crearEditarPersona());

        vista.getBtnSalir().addActionListener(l -> salir());

    }

    private void limpiarbusqueda() {
        vista.getTxtBuscar().setText("");
        cargaPersonas();
    }

    private void buscar() {
        List<Persona> listper = modelo.listarPersonas();
        String idBuscado = vista.getTxtBuscar().getText();

        DefaultTableModel modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Cedula");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Apellido");
        modeloTabla.addColumn("Edad");
        modeloTabla.addColumn("Teléfono");
        modeloTabla.addColumn("Sexo");
        modeloTabla.addColumn("Sueldo");
        modeloTabla.addColumn("Cupo");
        modeloTabla.addColumn("Imagen");

        for (Persona p : listper) {
            if (p.getId_persona().equals(idBuscado)) {
                Object[] fila = {
                    p.getId_persona(),
                    p.getNombres(),
                    p.getApellido(),
                    p.getEdadPersona(),
                    p.getTelefono(),
                    p.getSexo(),
                    p.getSueldo(),
                    p.getCupo(),};
                modeloTabla.addRow(fila);
            }
        }

        vista.getTblPersonas().setModel(modeloTabla);
    }

    public void salir() {
        MenuPrincipal menu = new MenuPrincipal();
        menu.setVisible(true);

        Controlador.ControladorPrincipal control = new ControladorPrincipal(menu);
        control.iniciacontrol();
        this.vista.dispose();
    }

    private void crearEditarPersona() {
        if (vista.getDialog1().getTitle().contentEquals("Crear")) {

            ModeloPersona p = new ModeloPersona();

            if (vista.getTxtcedula().equals("") || vista.getTxtnombre().equals("") || vista.getTxtapellido().equals("") || vista.getTxtFecha() == null || vista.getTxttelefono().equals("") || vista.getCMSexo().getSelectedItem().equals("SELECCIONE") || vista.getTxtsueldo().equals("") || vista.getTxtcupo().equals("")) {

                JOptionPane.showMessageDialog(null, "POR FAVOR LLENE LOS DATOS");

            } else {
                String cedula = vista.getTxtcedula().getText();
                String nombre = vista.getTxtnombre().getText();
                String apellido = vista.getTxtapellido().getText();
                String telefono = vista.getTxttelefono().getText();
                String sueldo = vista.getTxtsueldo().getText();
                String cupo = vista.getTxtcupo().getText();

                if (cedulaExiste(cedula)) {
                    JOptionPane.showMessageDialog(null, "La cédula ya existe. Por favor, ingrese una cédula diferente.");
                } else if (!validarCedula(cedula)) {
                    JOptionPane.showMessageDialog(null, "La cédula debe tener 10 dígitos.");
                } else if (!validarNombre(nombre)) {
                    JOptionPane.showMessageDialog(null, "El nombre debe ser valido");
                } else if (!validarApellido(apellido)) {
                    JOptionPane.showMessageDialog(null, "El apellido debe ser valido");
                } else if (!validarTelefono(telefono)) {
                    JOptionPane.showMessageDialog(null, "El teléfono debe tener 10 dígitos numéricos.");
                } else if (!validarSueldo(sueldo)) {
                    JOptionPane.showMessageDialog(null, "El sueldo debe ser un número válido.");
                } else if (!validarCupo(cupo)) {
                    JOptionPane.showMessageDialog(null, "El cupo debe ser un número válido.");

                } else {

                    p.setId_persona(cedula);
                    p.setNombres(nombre);
                    p.setApellido(apellido);
                    Date fechan = Date.valueOf(LocalDate.of(
                            vista.getTxtFecha().getDate().getYear() + 1900,
                            vista.getTxtFecha().getDate().getMonth() + 1,
                            vista.getTxtFecha().getDate().getDate()));
                    p.setFecha_Nac(fechan);

                    p.setTelefono(telefono);

                    if (vista.getCMSexo().getSelectedItem().equals("Masculino")) {
                        p.setSexo("Masculino");
                    } else if (vista.getCMSexo().getSelectedItem().equals("Femenino")) {
                        p.setSexo("Femenino");
                    }

                    p.setSueldo(sueldo);
                    p.setCupo(cupo);

                    if (p.grabarPersona()) {
                        limpiar();
                        JOptionPane.showMessageDialog(vista, "DATOS CREADOS");
                        vista.getDialog1().setVisible(false);
                        cargaPersonas();
                    } else {
                        JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");
                    }
                }
            }
        } else if (vista.getDialog1().getTitle().contentEquals("Editar")) {

            ModeloPersona p = new ModeloPersona();

            if (vista.getTxtcedula().equals("") || vista.getTxtnombre().equals("") || vista.getTxtapellido().equals("") || vista.getTxtFecha() == null || vista.getTxttelefono().equals("") || vista.getCMSexo().getSelectedItem().equals("SELECCIONE") || vista.getTxtsueldo().equals("") || vista.getTxtcupo().equals("")) {
                JOptionPane.showMessageDialog(null, "POR FAVOR LLENE LOS DATOS");
            } else {
                String cedula = vista.getTxtcedula().getText();
                String nombre = vista.getTxtnombre().getText();
                String apellido = vista.getTxtapellido().getText();
                String telefono = vista.getTxttelefono().getText();
                String sueldo = vista.getTxtsueldo().getText();
                String cupo = vista.getTxtcupo().getText();

                if (!validarCedula(cedula)) {
                    JOptionPane.showMessageDialog(null, "El campo de cédula debe tener 10 dígitos.");
                } else if (!validarNombre(nombre)) {
                    JOptionPane.showMessageDialog(null, "El nombre debe ser valido");
                } else if (!validarApellido(apellido)) {
                    JOptionPane.showMessageDialog(null, "El apellido debe ser valido");
                } else if (!validarTelefono(telefono)) {
                    JOptionPane.showMessageDialog(null, "El teléfono debe tener 10 dígitos numéricos.");
                } else if (!validarSueldo(sueldo)) {
                    JOptionPane.showMessageDialog(null, "El sueldo debe ser un número válido.");
                } else if (!validarCupo(cupo)) {
                    JOptionPane.showMessageDialog(null, "El cupo debe ser un número válido.");

                } else {
                    p.setId_persona(cedula);
                    p.setNombres(nombre);
                    p.setApellido(apellido);
                    Date fechan = Date.valueOf(LocalDate.of(
                            vista.getTxtFecha().getDate().getYear() + 1900,
                            vista.getTxtFecha().getDate().getMonth() + 1,
                            vista.getTxtFecha().getDate().getDate()));
                    p.setFecha_Nac(fechan);

                    p.setTelefono(telefono);

                    if (vista.getCMSexo().getSelectedItem().equals("Masculino")) {
                        p.setSexo("Masculino");
                    } else if (vista.getCMSexo().getSelectedItem().equals("Femenino")) {
                        p.setSexo("Femenino");
                    }

                    p.setSueldo(sueldo);
                    p.setCupo(cupo);

                    if (p.ModificarPersona()) {
                        limpiar();
                        JOptionPane.showMessageDialog(vista, "DATOS CREADOS");
                        vista.getDialog1().setVisible(false);
                        cargaPersonas();
                    } else {
                        JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");
                    }
                }
            }

        } else if (vista.getDialog1().getTitle().contentEquals("Eliminar")) {
            ModeloPersona p = new ModeloPersona();
            p.setId_persona(vista.getTxtcedula().getText());
            if (p.EliminarPersona()) {

                limpiar();
                JOptionPane.showMessageDialog(vista, "DATOS ELIMINADOS");

                vista.getDialog1().setVisible(false);
                cargaPersonas();

            } else {
                JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");
            }

        }
    }

    public void salirdialogo() {
        limpiar();
        vista.getDialog1().setVisible(false);
    }

    private void limpiar() {
        vista.getTxtcedula().setText("");
        vista.getTxtnombre().setText("");
        vista.getTxtapellido().setText("");
        vista.getTxtsueldo().setText("");
        vista.getTxtcupo().setText("");
        vista.getCMSexo().setSelectedItem("SELECCIONE");
        vista.getTxtFecha().setDate(null);
        vista.getTxttelefono().setText("");
        vista.getTxtcedula().setEnabled(true);

    }

    private void abrirDialogo(String ce) {

        vista.getDialog1().setLocationRelativeTo(null);
        vista.getDialog1().setSize(750, 600);
        vista.getDialog1().setTitle(ce);
        vista.getDialog1().setVisible(true);
        if (vista.getDialog1().getTitle().contentEquals("Crear")) {

        } else if (vista.getDialog1().getTitle().contentEquals("Editar")) {

            LlenarDatos();

        } else if (vista.getDialog1().getTitle().contentEquals("Eliminar")) {
            LlenarDatos();
        }
    }

    private void cargaPersonas() {
        DefaultTableModel mJtable1;
        mJtable1 = (DefaultTableModel) vista.getTblPersonas().getModel();
        mJtable1.setNumRows(0);
        List<Persona> listaP = modelo.listarPersonas();
        listaP.stream().forEach(p -> {
            String[] rowData = {p.getId_persona(), p.getNombres(), p.getApellido(), String.valueOf(p.getEdadPersona()), p.getTelefono(), p.getSexo(), p.getSueldo(), p.getCupo()};
            mJtable1.addRow(rowData);
        }
        );
    }

    public void LlenarDatos() {

        List<Persona> listper = modelo.listarPersonas();
        int selectedRow = vista.getTblPersonas().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para que los datos se llenen, debe seleccionar un elemento de la tabla");
        } else {
            String selectedId = vista.getTblPersonas().getValueAt(selectedRow, 0).toString();
            Optional<Persona> matchingPersona = listper.stream()
                    .filter(p -> selectedId.equals(p.getId_persona()))
                    .findFirst();

            if (matchingPersona.isPresent()) {
                Persona p = matchingPersona.get();

                vista.getTxtcedula().setText(p.getId_persona());
                vista.getTxtcedula().setEnabled(false);
                vista.getTxtnombre().setText(p.getNombres());
                vista.getTxtapellido().setText(p.getApellido());
                vista.getTxttelefono().setText(p.getTelefono());
                vista.getTxtsueldo().setText(p.getSueldo());
                vista.getTxtcupo().setText(p.getCupo());
                vista.getTxtFecha().setDate(p.getFecha_Nac());

                //   vista.getImagenIngreso().(p.getFecha_Nac());
                if (p.getSexo().equals("Masculino")) {
                    vista.getCMSexo().setSelectedItem("Masculino");
                } else if (p.getSexo().equals("Femenino")) {
                    vista.getCMSexo().setSelectedItem("Femenino");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    private boolean cedulaExiste(String cedula) {
        try {
            List<Persona> listaPersonas = modelo.listarPersonas();

            for (Persona persona : listaPersonas) {
                if (persona.getId_persona().equals(cedula)) {
                    return true;
                }
            }
        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "Error al obtener la lista de personas: " + e.getMessage());
        }

        return false;
    }

    public boolean validarNombre(String nombre) {

        return nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{2,50}");
    }

    public boolean validarApellido(String apellido) {

        return apellido.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{2,50}");
    }

    public boolean validarTelefono(String telefono) {

        return telefono.matches("\\d{10}");
    }

    public boolean validarCedula(String cedula) {

        return cedula.matches("\\d{10}");
    }

    public boolean validarSueldo(String sueldo) {

        return sueldo.matches("\\d+(\\.\\d+)?");
    }

    public boolean validarCupo(String cupo) {

        return cupo.matches("\\d+");
    }
}
