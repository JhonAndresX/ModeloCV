/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ConexionPostgres;
import Modelo.ModeloDetalle;
import Modelo.ModeloFactura;
import Modelo.DetalleFac;
import Modelo.EncabezadoFac;
import Modelo.ModeloPersona;
import Modelo.ModeloProducto;
import Modelo.Persona;
import Modelo.Producto;
import Vista.Factura;
import Vista.MenuPrincipal;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.util.Optional;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ControladorFactura {

    private ModeloDetalle modeloDet;
    private ModeloFactura modeloFac;
    private ModeloPersona modeloPer;
    private ModeloProducto modeloPro;
    private Factura vista;
    ConexionPostgres CPG = new ConexionPostgres();

    public ControladorFactura(ModeloDetalle modeloDet, ModeloFactura modeloFac, ModeloProducto modeloPro, ModeloPersona modeloPer, Factura vista) {
        this.modeloDet = modeloDet;
        this.modeloFac = modeloFac;
        this.modeloPro = modeloPro;
        this.modeloPer = modeloPer;
        this.vista = vista;
        vista.setVisible(true);
        cargaFactura();
        cargaProductos();
        cargaPersonas();
        vista.getTxtProducto().setEnabled(false);
        vista.getTxtPrecio().setEnabled(false);
        vista.getTxtCliente().setEnabled(false);
        vista.getTxtTotalDe().setEnabled(false);
        vista.getBtnAceptar().setVisible(false);
        vista.getTxtEncabezado().setEnabled(false);
        vista.getTxtidDetalle().setEnabled(false);
    }

    public void iniciaControl() {
        vista.getBtnConsultar().addActionListener(l -> buscar());
        vista.getBtnCrear().addActionListener(l -> abrirDialogo("Crear"));
        vista.getAgregarPro().addActionListener(l -> Mostrar());
        vista.getGuardar().addActionListener(l -> vista.getBtnAceptar().setVisible(true));
        vista.getAgregarPro().addActionListener(l -> vista.getBtnAceptar().setVisible(true));
        vista.getAgregarPro().addActionListener(l -> detallesconencabezado());
        vista.getAgregarPro().addActionListener(l -> LlenarEncabezado());
        vista.getAgregarPro().addActionListener(l -> abrirDialogo("AgregarProducto"));
        vista.getBtnCrear().addActionListener(l -> {
            try {
                CargarID();
                CargarEncabezado();
            } catch (SQLException ex) {
                Logger.getLogger(ControladorFactura.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        vista.getAgregarPro().addActionListener(l -> {
            try {
                CargarID();
                CargarEncabezado();
            } catch (SQLException ex) {
                Logger.getLogger(ControladorFactura.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        vista.getBtnEditar().addActionListener(l -> abrirDialogo("Editar"));

        vista.getBtnEditar().addActionListener(l -> detallesconencabezado());

        vista.getBtnEditar().addActionListener(l -> {
            try {
                CargarID();
                CargarEncabezado();
            } catch (SQLException ex) {
                Logger.getLogger(ControladorFactura.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        vista.getBtnRemover().addActionListener(l -> abrirDialogo("Eliminar"));
        vista.getBtnRemover().addActionListener(l -> {
            try {
                CargarID();
            } catch (SQLException ex) {
                Logger.getLogger(ControladorFactura.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        vista.getBtnLimpiar().addActionListener(l -> limpiarbusqueda());
        vista.getBtnAceptar().addActionListener(l -> Detalle());
        vista.getBtnAceptar().addActionListener(l -> AgregarProductos());
        vista.getBtnSalir1().addActionListener(l -> salirdialogo());
        vista.getGuardar().addActionListener(l -> Encabezado());

        vista.getBtnSalir().addActionListener(l -> salir());

        vista.getTblPersonaDLG().addMouseListener(new MouseAdapter() {
            @Override                
            public void mouseClicked(MouseEvent e) {
                LlenarDatosPersona();
            }
        });
        vista.getTablaDetalles().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                LlenarProductosAdquiridos();
            }
        });
        vista.getTblProductoDLG().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                LlenarDatosProducto();
            }
        });
        vista.getSpnCantidad().addChangeListener(e -> {
            double numero1 = Double.parseDouble(vista.getTxtPrecio().getText());
            double numero2 = Double.parseDouble(vista.getSpnCantidad().getValue().toString());
            double resultado = numero1 * numero2;
            vista.getTxtTotalDe().setText(String.valueOf(resultado));
        });
    }

    private void limpiarbusqueda() {
        vista.getTxtBuscar().setText("");
        cargaFactura();
    }

    private void Mostrar() {
        vista.getGuardar().setVisible(false);
        vista.getTblPersonaDLG().setVisible(false);

    }

    private void CargarID() throws SQLException {
        vista.getTxtidDetalle().setText(String.valueOf(modeloDet.CargarCodigoDetalle()));
    }

    private void CargarEncabezado() throws SQLException {
        vista.getTxtEncabezado().setText(String.valueOf(modeloFac.CargarCodigoEncabezado()));
    }

    private void buscar() {
        List<EncabezadoFac> listaEncabezado = modeloFac.listaEncabezado();
        String idBuscado = vista.getTxtBuscar().getText();

        DefaultTableModel modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("IdEncabezado");
        modeloTabla.addColumn("IdCliente");
        modeloTabla.addColumn("Fecha");
        modeloTabla.addColumn("Total");

        for (EncabezadoFac p : listaEncabezado) {

            if (p.getIdfactura().equals(idBuscado)) {

                Object[] fila = {
                    p.getIdfactura(),
                    p.getCliente(),
                    p.getFecha(),
                    p.getTotal()};
                modeloTabla.addRow(fila);
            }

        }

        vista.getTblFactura().setModel(modeloTabla);
    }

    private void detallesconencabezado() {
        List<DetalleFac> listaDetalles = modeloDet.listadetalle();
        int selectedRow = vista.getTblFactura().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para que los datos se llenen, debe seleccionar un elemento de la tabla");
        } else {
            String selectedId = vista.getTblFactura().getValueAt(selectedRow, 0).toString();

            Optional<DetalleFac> matchingEncabezado = listaDetalles.stream()
                    .filter(p -> selectedId.equals(p.getIdfactura()))
                    .findFirst();
            if (matchingEncabezado.isPresent()) {
                DetalleFac d = matchingEncabezado.get();

                DefaultTableModel modeloTabla = new DefaultTableModel();

                vista.getTxtEncabezado().setText(d.getIdfactura());
                String idEncabezado = vista.getTxtEncabezado().getText();
                modeloTabla.addColumn("IdDetalle");
                modeloTabla.addColumn("IdEncabezado");
                modeloTabla.addColumn("Producto");
                modeloTabla.addColumn("Cantidad");
                modeloTabla.addColumn("Precio");

                for (DetalleFac detalle : listaDetalles) {
                    if (detalle.getIdfactura().equals(idEncabezado)) {
                        Object[] fila = {detalle.getIddetalle(), detalle.getIdfactura(), detalle.getProducto(), detalle.getCantidad(), detalle.getPrecio()};
                        modeloTabla.addRow(fila);
                    }
                }
                vista.getTablaDetalles().setModel(modeloTabla);
            }

        }
    }

    private void Encabezado() {
        if (vista.getDialogFac().getTitle().contentEquals("Crear")) {
            ModeloFactura p = new ModeloFactura();
            if (vista.getTxtCliente().getText().equals("") || vista.getTxtEncabezado().getText().equals("") || vista.getTxtFecha().getDate() == null || vista.getTxtTotalDe().getText().equals("")) {
                JOptionPane.showMessageDialog(null, "POR FAVOR LLENE LOS DATOS");
            } else {

                String codigo = vista.getTxtEncabezado().getText();

                p.setIdfactura(codigo);

                p.setCliente(vista.getTxtCliente().getText());

                p.setTotal(Double.valueOf(vista.getTxtTotalDe().getText()));

                java.sql.Date fechan = java.sql.Date.valueOf(LocalDate.of(
                        vista.getTxtFecha().getDate().getYear() + 1900,
                        vista.getTxtFecha().getDate().getMonth() + 1,
                        vista.getTxtFecha().getDate().getDate()));
                p.setFecha(fechan);
                if (p.grabarEncabezado()) {
                    cargaProductos();
                    JOptionPane.showMessageDialog(vista, "DATOS CREADOS");

                    cargaFactura();

                }

            }
        } else if (vista.getDialogFac().getTitle().contentEquals("Editar")) {
            ModeloFactura p = new ModeloFactura();

            if (vista.getTxtCliente().getText().equals("") || vista.getTxtEncabezado().getText().equals("") || vista.getTxtFecha().getDate() == null || vista.getTxtTotalDe().getText().equals("")) {
                JOptionPane.showMessageDialog(null, "POR FAVOR LLENE LOS DATOS");

            } else {
                String codigo = vista.getTxtEncabezado().getText();

                p.setIdfactura(codigo);

                p.setCliente(vista.getTxtCliente().getText());

                p.setCliente(vista.getTxtCliente().getText());

                double total1 = calcularTotal();
                p.setTotal(total1);

                java.sql.Date fechan = java.sql.Date.valueOf(LocalDate.of(
                        vista.getTxtFecha().getDate().getYear() + 1900,
                        vista.getTxtFecha().getDate().getMonth() + 1,
                        vista.getTxtFecha().getDate().getDate()));
                p.setFecha(fechan);
                if (p.ModificarEncabeza()) {

                    JOptionPane.showMessageDialog(vista, "DATOS ACTUALIZADOS");
                    cargaProductos();
                    cargaFactura();

                }
            }

        } else if (vista.getDialogFac()
                .getTitle().contentEquals("Eliminar")) {
            ModeloFactura p = new ModeloFactura();

            p.setIdfactura(vista.getTxtEncabezado().getText());

            if (p.EliminarEncabeza()) {
                cargaProductos();
                JOptionPane.showMessageDialog(vista, "DATOS ELIMINADOS");
                vista.getDialogFac().setVisible(false);
                cargaFactura();
                limpiar();

            }
        }
    }

    private void Detalle() {
        if (vista.getDialogFac().getTitle().contentEquals("Crear")) {

            ModeloDetalle d = new ModeloDetalle();
            if (vista.getTxtCliente().getText().equals("") || vista.getTxtEncabezado().getText().equals("") || vista.getTxtFecha().getDate() == null || vista.getTxtTotalDe().getText().equals("")) {
                JOptionPane.showMessageDialog(null, "POR FAVOR LLENE LOS DATOS");
            } else {
                d.setIddetalle(vista.getTxtidDetalle().getText());
                d.setIdfactura(vista.getTxtEncabezado().getText());

                d.setProducto(vista.getTxtProducto().getText());

                d.setCantidad(Integer.parseInt(vista.getSpnCantidad().getValue().toString()));
                d.setPrecio(Double.parseDouble(vista.getTxtPrecio().getText()));
                d.setTotal(Double.parseDouble(vista.getTxtTotalDe().getText()));

                if (d.grabarDetalle()) {
                    cargaProductos();
                    JOptionPane.showMessageDialog(vista, "DATOS CREADOS");
                    vista.getDialogFac().setVisible(false);
                    cargaFactura();
                    limpiar();
                } else {
                    JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");

                }

            }
        } else if (vista.getDialogFac().getTitle().contentEquals("Editar")) {

            ModeloDetalle d = new ModeloDetalle();

            if (vista.getTxtCliente().getText().equals("") || vista.getTxtidDetalle().getText().equals("") || vista.getTxtEncabezado().getText().equals("") || vista.getTxtPrecio().getText().equals("")) {
                JOptionPane.showMessageDialog(null, "POR FAVOR LLENE LOS DATOS");
            } else {
                d.setIddetalle(vista.getTxtidDetalle().getText());
                d.setIdfactura(vista.getTxtEncabezado().getText());

                d.setProducto(vista.getTxtProducto().getText());

                d.setCantidad(Integer.parseInt(vista.getSpnCantidad().getValue().toString()));
                d.setPrecio(Double.parseDouble(vista.getTxtPrecio().getText()));
                d.setTotal(Double.parseDouble(vista.getTxtTotalDe().getText()));

                if (d.ModificarDetalle()) {
                    cargaProductos();
                    JOptionPane.showMessageDialog(vista, "DATOS ACTUALIZADOS");
                    vista.getDialogFac().setVisible(false);
                    cargaFactura();
                    limpiar();
                } else {
                    JOptionPane.showMessageDialog(vista, "ERROR AL ACTUALIZAR DATOS");
                }
            }

        } else if (vista.getDialogFac()
                .getTitle().contentEquals("Eliminar")) {
            ModeloFactura p = new ModeloFactura();
            ModeloDetalle d = new ModeloDetalle();

            p.setIdfactura(vista.getTxtEncabezado().getText());
            d.setIddetalle(vista.getTxtidDetalle().getText());

            if (d.EliminarDetalle()) {
                cargaProductos();
                JOptionPane.showMessageDialog(vista, "DATOS ELIMINADOS");
                vista.getDialogFac().setVisible(false);
                cargaFactura();
                limpiar();
            } else {
                JOptionPane.showMessageDialog(vista, "ERROR AL ELIMINAR DATOS");
            }

        }
    }

    private void AgregarProductos() {
        if (vista.getDialogFac().getTitle().contentEquals("AgregarProducto")) {
            ModeloDetalle d = new ModeloDetalle();
            ModeloFactura p = new ModeloFactura();
            ModeloProducto a = new ModeloProducto();

            d.setIddetalle(vista.getTxtidDetalle().getText());
            d.setIdfactura(vista.getTxtEncabezado().getText());
            d.setProducto(vista.getTxtProducto().getText());
            d.setCantidad(Integer.parseInt(vista.getSpnCantidad().getValue().toString()));
            d.setPrecio(Double.parseDouble(vista.getTxtPrecio().getText()));
            d.setTotal(Double.parseDouble(vista.getTxtTotalDe().getText()));
            p.setIdfactura(vista.getTxtEncabezado().getText());
            p.setCliente(vista.getTxtCliente().getText());

            double total = calcularTotal();
            p.setTotal(total);

            java.sql.Date fechan = java.sql.Date.valueOf(LocalDate.of(
                    vista.getTxtFecha().getDate().getYear() + 1900,
                    vista.getTxtFecha().getDate().getMonth() + 1,
                    vista.getTxtFecha().getDate().getDate()));
            p.setFecha(fechan);

            if (p.ModificarEncabeza()) {
                if (d.grabarDetalle()) {

                    int fila = vista.getTblProductoDLG().getSelectedRow();
                    int codigoproducto = Integer.valueOf(vista.getTblProductoDLG().getValueAt(fila, 0).toString());
                    int cantidadproducto = Integer.valueOf(vista.getTblProductoDLG().getValueAt(fila, 2).toString());
                    int cantidad = Integer.parseInt(vista.getSpnCantidad().getValue().toString());
                    int resultado = cantidadproducto - Integer.parseInt(vista.getSpnCantidad().getValue().toString());

                    a.setCodigo(String.valueOf(codigoproducto));
                    a.setCantidad(String.valueOf(resultado));
                    if (a.actualizarCantidadProducto()) {
                        cargaProductos();
                        JOptionPane.showMessageDialog(vista, "DATOS ACTUALIZADOS");
                        cargaFactura();
                    }

                }

                JOptionPane.showMessageDialog(vista, "DATOS CREADOS");
                vista.getDialogFac().setVisible(false);
                cargaFactura();
                limpiar();
            } else {
                JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");
            }
        } else if (vista.getDialogFac()
                .getTitle().contentEquals("EliminarProductos")) {
            ModeloDetalle d = new ModeloDetalle();
            ModeloFactura p = new ModeloFactura();
            d.setIddetalle(vista.getTxtidDetalle().getText());

            if (d.EliminarDetalle()) {
                p.setIdfactura(vista.getTxtEncabezado().getText());

                p.setCliente(vista.getTxtCliente().getText());

                double total = calcularTotal();
                p.setTotal(total);

                java.sql.Date fechan = java.sql.Date.valueOf(LocalDate.of(
                        vista.getTxtFecha().getDate().getYear() + 1900,
                        vista.getTxtFecha().getDate().getMonth() + 1,
                        vista.getTxtFecha().getDate().getDate()));
                p.setFecha(fechan);
                if (p.ModificarEncabeza()) {
                    JOptionPane.showMessageDialog(vista, "DATOS ACTUALIZADOS");
                    cargaFactura();
                }

                JOptionPane.showMessageDialog(vista, "DATOS ELIMINADOS");
                vista.getDialogFac().setVisible(false);
                cargaFactura();
                limpiar();

            }
        }
    }

    private void limpiar() {
        vista.getTxtEncabezado().setText("");
        vista.getTxtFecha().setDate(null);
        vista.getTxtCliente().setText("");
        vista.getTxtidDetalle().setText("");
        vista.getTxtProducto().setText("");

        vista.getSpnCantidad().setValue(0);
        vista.getTxtPrecio().setText("");
        vista.getBtnAceptar().setVisible(false);
        vista.getTxtTotalDe().setText("");
        vista.getGuardar().setVisible(true);
        vista.getTblPersonaDLG().setVisible(true);

    }

    private void abrirDialogo(String ce) {
        vista.getDialogFac().setLocation(0, 0);
        vista.getDialogFac().setSize(1350, 720);
        vista.getDialogFac().setTitle(ce);
        vista.getDialogFac().setVisible(true);
        if (vista.getDialogFac().getTitle().contentEquals("Crear")) {
            // Código para inicializar la creación
        } else if (vista.getDialogFac().getTitle().contentEquals("Editar")) {
            LlenarDatos();
        } else if (vista.getDialogFac().getTitle().contentEquals("Eliminar")) {
            LlenarDatos();
        }
    }

    private void cargaFactura() {
        DefaultTableModel mJtable = (DefaultTableModel) vista.getTblFactura().getModel();
        mJtable.setNumRows(0);
        List<EncabezadoFac> listaP = modeloFac.listaEncabezado();
        for (EncabezadoFac p : listaP) {

            String[] rowData = {p.getIdfactura(), p.getCliente(), String.valueOf(p.getFecha()), String.valueOf(p.getTotal())};
            mJtable.addRow(rowData);

        }
    }

    private void cargaPersonas() {
        DefaultTableModel mJtable1;
        mJtable1 = (DefaultTableModel) vista.getTblPersonaDLG().getModel();
        mJtable1.setNumRows(0);
        List<Persona> listper = modeloPer.listarPersonas();
        listper.stream().forEach(p -> {
            String[] rowData = {p.getId_persona(), p.getNombres(), p.getApellido()};
            mJtable1.addRow(rowData);
        }
        );
    }

    public void cargaProductos() {
        DefaultTableModel mJtable2 = (DefaultTableModel) vista.getTblProductoDLG().getModel();
        mJtable2.setNumRows(0);
        List<Producto> listaP = modeloPro.listarProductos();
        for (Producto p : listaP) {
            String[] rowData = {
                p.getCodigo(),
                p.getNombre(),
                p.getCantidad(),
                p.getPrecio()
            };
            mJtable2.addRow(rowData);
        }
    }

    public void LlenarDatosPersona() {

        List<Persona> listper = modeloPer.listarPersonas();
        int selectedRow = vista.getTblPersonaDLG().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para que los datos se llenen, debe seleccionar un elemento de la tabla");
        } else {
            String selectedId = vista.getTblPersonaDLG().getValueAt(selectedRow, 0).toString();
            Optional<Persona> matchingPersona = listper.stream()
                    .filter(p -> selectedId.equals(p.getId_persona()))
                    .findFirst();

            if (matchingPersona.isPresent()) {
                Persona p = matchingPersona.get();
                vista.getTxtCliente().setText(p.getNombres());

            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    public void LlenarDatosProducto() {

        List<Producto> listper = modeloPro.listarProductos();
        int selectedRow = vista.getTblProductoDLG().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para que los datos se llenen, debe seleccionar un elemento de la tabla");
        } else {
            String selectedId = vista.getTblProductoDLG().getValueAt(selectedRow, 0).toString();
            Optional<Producto> matchingProducto = listper.stream()
                    .filter(p -> selectedId.equals(p.getCodigo()))
                    .findFirst();

            if (matchingProducto.isPresent()) {
                Producto p = matchingProducto.get();
                vista.getTxtPrecio().setText(p.getPrecio());

                vista.getTxtProducto().setText(p.getNombre());

            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    public void LlenarDatos() {
        List<EncabezadoFac> listaP = modeloFac.listaEncabezado();
        List<DetalleFac> listaD = modeloDet.listadetalle();
        int selectedRow = vista.getTblFactura().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para llenar los datos, debe seleccionar un elemento de la tabla.");
        } else {
            String selectedId = vista.getTblFactura().getValueAt(selectedRow, 0).toString();
            String selectedid1 = vista.getTblFactura().getValueAt(selectedRow, 0).toString();
            Optional<EncabezadoFac> matchingEncabezado = listaP.stream()
                    .filter(p -> selectedId.equals(p.getIdfactura()))
                    .findFirst();
            Optional<DetalleFac> matchingDetalle = listaD.stream()
                    .filter(d -> selectedid1.equals(d.getIdfactura())).findFirst();

            if (matchingEncabezado.isPresent() && matchingDetalle.isPresent()) {
                EncabezadoFac p = matchingEncabezado.get();
                DetalleFac d = matchingDetalle.get();
                vista.getTxtEncabezado().setText(p.getIdfactura());
                vista.getTxtFecha().setDate(p.getFecha());
                vista.getTxtCliente().setText(p.getCliente());
                vista.getTxtidDetalle().setText(d.getIddetalle());
                vista.getTxtProducto().setText(d.getProducto());
                vista.getTxtPrecio().setText(String.valueOf(d.getPrecio()));
                vista.getSpnCantidad().setValue(d.getCantidad());
                vista.getTxtTotalDe().setText(String.valueOf(p.getTotal()));
                vista.getTxtEncabezado().setEnabled(false);

                vista.getTxtProducto().setEnabled(false);
                vista.getTxtPrecio().setEnabled(false);
                vista.getTxtCliente().setEnabled(false);
                vista.getTxtTotalDe().setEnabled(false);

            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    public void LlenarEncabezado() {
        List<EncabezadoFac> listaP = modeloFac.listaEncabezado();
        List<DetalleFac> listaD = modeloDet.listadetalle();
        int selectedRow = vista.getTblFactura().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para llenar los datos, debe seleccionar un elemento de la tabla.");
        } else {
            String selectedId = vista.getTblFactura().getValueAt(selectedRow, 0).toString();
            String selectedid1 = vista.getTblFactura().getValueAt(selectedRow, 0).toString();
            Optional<EncabezadoFac> matchingEncabezado = listaP.stream()
                    .filter(p -> selectedId.equals(p.getIdfactura()))
                    .findFirst();
            Optional<DetalleFac> matchingDetalle = listaD.stream()
                    .filter(d -> selectedid1.equals(d.getIdfactura())).findFirst();

            if (matchingEncabezado.isPresent() && matchingDetalle.isPresent()) {
                EncabezadoFac p = matchingEncabezado.get();
                DetalleFac d = matchingDetalle.get();
                vista.getTxtEncabezado().setText(p.getIdfactura());
                vista.getTxtFecha().setDate(p.getFecha());
                vista.getTxtCliente().setText(p.getCliente());

                vista.getTxtEncabezado().setEnabled(false);
                vista.getTxtFecha().setEnabled(false);

                vista.getTxtProducto().setEnabled(false);
                vista.getTxtPrecio().setEnabled(false);
                vista.getTxtCliente().setEnabled(false);
                vista.getTxtTotalDe().setEnabled(false);

            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    public void salirdialogo() {
        limpiar();
        vista.getDialogoFac().setVisible(false);
    }

    public void LlenarProductos() {
        List<EncabezadoFac> listaP = modeloFac.listaEncabezado();
        List<DetalleFac> listaD = modeloDet.listadetalle();
        int selectedRow = vista.getTblFactura().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para llenar los datos, debe seleccionar un elemento de la tabla.");
        } else {
            String selectedId = vista.getTblFactura().getValueAt(selectedRow, 0).toString();
            String selectedid1 = vista.getTblFactura().getValueAt(selectedRow, 1).toString();
            Optional<EncabezadoFac> matchingEncabezado = listaP.stream()
                    .filter(p -> selectedId.equals(p.getIdfactura()))
                    .findFirst();
            Optional<DetalleFac> matchingDetalle = listaD.stream()
                    .filter(d -> selectedid1.equals(d.getIddetalle())).findFirst();

            if (matchingEncabezado.isPresent() && matchingDetalle.isPresent()) {
                EncabezadoFac p = matchingEncabezado.get();
                DetalleFac d = matchingDetalle.get();
                vista.getTxtEncabezado().setText(p.getIdfactura());
                vista.getTxtFecha().setDate(p.getFecha());
                vista.getTxtCliente().setText(p.getCliente());

                vista.getTxtEncabezado().setEnabled(false);
                vista.getTxtProducto().setEnabled(false);
                vista.getTxtPrecio().setEnabled(false);
                vista.getTxtCliente().setEnabled(false);
                vista.getTxtTotalDe().setEnabled(false);
            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    public void LlenarProductosAdquiridos() {
        List<EncabezadoFac> listaP = modeloFac.listaEncabezado();
        List<DetalleFac> listaD = modeloDet.listadetalle();
        int selectedRow = vista.getTablaDetalles().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para llenar los datos, debe seleccionar un elemento de la tabla.");
        } else {
            String selectedId = vista.getTablaDetalles().getValueAt(selectedRow, 0).toString();

            Optional<DetalleFac> matchingDetalle = listaD.stream()
                    .filter(d -> selectedId.equals(d.getIddetalle())).findFirst();

            if (matchingDetalle.isPresent()) {

                DetalleFac p = matchingDetalle.get();
                vista.getTxtPrecio().setText(String.valueOf(p.getPrecio()));
                vista.getTxtProducto().setText(p.getProducto());
                vista.getTxtTotalDe().setText(String.valueOf(p.getTotal()));
                vista.getTxtidDetalle().setText(String.valueOf(p.getIddetalle()));
                // vista.getSpnCantidad().setValue(String.valueOf(p.getCantidad()));

                vista.getTxtEncabezado().setEnabled(false);
                vista.getTxtProducto().setEnabled(false);
                vista.getTxtPrecio().setEnabled(false);
                vista.getTxtCliente().setEnabled(false);
                vista.getTxtTotalDe().setEnabled(false);
            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    public void salir() {
        MenuPrincipal menu = new MenuPrincipal();
        menu.setVisible(true);

        Controlador.ControladorPrincipal control = new ControladorPrincipal(menu);
        control.iniciacontrol();
        this.vista.dispose();
    }

    private boolean codigoExiste(String codigo) {
        List<EncabezadoFac> listaP = modeloFac.listaEncabezado();

        for (EncabezadoFac encabezado : listaP) {
            if (encabezado.getIdfactura().equals(codigo)) {
                return true;
            }
        }

        return false;
    }

    public void stock() {

        try {

        } catch (Exception e) {

        }

    }

    public boolean actualizarCantidadProducto(int codigoProducto, int nuevaCantidadProducto) {

        int fila = vista.getTblProductoDLG().getSelectedRow();
        int cantidadBase = Integer.valueOf(vista.getTblProductoDLG().getValueAt(fila, 2).toString());
        int codigoproducto = Integer.valueOf(vista.getTblProductoDLG().getValueAt(fila, 0).toString());

        int cantidadcompra = (int) vista.getSpnCantidad().getValue();

        int result = cantidadBase - cantidadcompra;
        String sql = "UPDATE productos SET cantidad_producto = " + result + " WHERE codigo_producto = '" + codigoproducto + "'";

        return CPG.accionBD(sql);
    }

    public boolean validarNombre(String nombre) {
        return nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{2,50}");
    }

    public boolean validarDescripcion(String descripcion) {
        return descripcion.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{2,99}");
    }

    public boolean validarCodigo(String codigo) {
        return codigo.matches("\\d{5}");
    }

    public boolean validarPrecio(String precio) {
        return precio.matches("\\d+(\\.\\d+)?");
    }

    public boolean validarCantidad(String cantidad) {
        return cantidad.matches("\\d+");
    }

    private double calcularTotal() {
        double total = 0;

        DefaultTableModel modeloTabla = (DefaultTableModel) vista.getTablaDetalles().getModel();
        int rowCount = modeloTabla.getRowCount();

        for (int i = 0; i < rowCount; i++) {
            double precio = Double.parseDouble(modeloTabla.getValueAt(i, 4).toString());
            int cantidad = Integer.parseInt(modeloTabla.getValueAt(i, 3).toString());
            double subtotal = precio * cantidad;
            total += subtotal;
        }

        return total;
    }
}
